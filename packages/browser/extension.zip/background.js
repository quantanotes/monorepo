// extension/background.ts
function ok(send2, data2) {
  send2({ ok: true, data: data2 });
}
function error(send2, error2) {
  send2({ ok: false, error: error2 });
}
function getInteractableElementsDOM() {
  return Array.from(document.querySelectorAll("button, input, a, select, textarea"));
}
function getInteractableElements() {
  return getInteractableElementsDOM().map((el, index) => ({
    index,
    tag: el.tagName,
    text: el.innerText,
    value: el.value
  }));
}
function executeAndSendInTab(tabId, func, send2) {
  return chrome.scripting.executeScript({
    target: { tabId },
    func
  }, (results) => {
    if (chrome.runtime.lastError) {
      error(send2, chrome.runtime.lastError);
      return;
    }
    ok(send2, results[0]?.result);
  });
}
async function list(send2) {
  const tabs = await chrome.tabs.query({});
  ok(send2, tabs);
}
async function begin(send2) {
  const tab = await chrome.tabs.create({ active: false });
  ok(send2, { tabId: tab.id });
}
function end(send2, data2) {
  chrome.tabs.remove(data2.tabId);
  ok(send2, undefined);
}
async function goto(send2, data2) {
  try {
    await chrome.tabs.update(data2.tabId, { url: data2.url });
    ok(send2, {});
  } catch (error2) {
    error2(send2, error2.message);
  }
}
function get(send2, data2) {
  function get2() {
    function getInteractableElementsDOM2() {
      return Array.from(document.querySelectorAll("button, input, a, select, textarea"));
    }
    function getInteractableElements2() {
      return getInteractableElementsDOM2().map((el, index) => ({
        index,
        tag: el.tagName,
        text: el.innerText,
        value: el.value
      }));
    }
    const html = document.documentElement.outerHTML;
    const interactables = getInteractableElements2();
    return { html, interactables };
  }
  executeAndSendInTab(data2.tabId, get2, send2);
}
function click(send2, data2) {
  function click2() {
    function getInteractableElementsDOM2() {
      return Array.from(document.querySelectorAll("button, input, a, select, textarea"));
    }
    const el = getInteractableElementsDOM2()[data2.index];
    el.click();
  }
  executeAndSendInTab(data2.tabId, click2, send2);
}
function type(send2, data2) {
  function type2() {
    function getInteractableElementsDOM2() {
      return Array.from(document.querySelectorAll("button, input, a, select, textarea"));
    }
    const el = getInteractableElementsDOM2()[data2.index];
    el.value = data2.text;
  }
  executeAndSendInTab(data2.tabId, type2, send2);
}
function run2(send, data) {
  function run() {
    eval(data.code);
  }
  executeAndSendInTab(data.tabId, run, send);
}
function waitForNetworkIdle(send2, data2) {
  function watchNetworkIdle() {
    return new Promise((resolve) => {
      const timeout = 500;
      let last = Date.now();
      const observer = new PerformanceObserver(() => {
        last = Date.now();
      });
      observer.observe({ entryTypes: ["resource"] });
      const checkInterval = setInterval(() => {
        const now = Date.now();
        if (now - last >= timeout) {
          clearInterval(checkInterval);
          observer.disconnect();
          resolve();
        }
      }, 100);
    });
  }
  executeAndSendInTab(data2.tabId, watchNetworkIdle, send2);
}
function waitForSelector(send2, data2) {
  function watchSelector() {
    return new Promise((resolve) => {
      const start = Date.now();
      const checkSelector = () => {
        const element = document.querySelector(data2.selector);
        if (element) {
          resolve(true);
          return;
        }
        if (Date.now() - start >= data2.timeout) {
          resolve(false);
          return;
        }
        setTimeout(checkSelector, 100);
      };
      checkSelector();
    });
  }
  executeAndSendInTab(data2.tabId, watchSelector, send2);
}
function waitForEvent(send2, data2) {
  function watchEvent() {
    return new Promise((resolve) => {
      const start = Date.now();
      const eventHandler = () => {
        resolve(true);
        document.removeEventListener(data2.event, eventHandler);
      };
      document.addEventListener(data2.event, eventHandler);
      setTimeout(() => {
        if (Date.now() - start >= data2.timeout) {
          resolve(false);
          document.removeEventListener(data2.event, eventHandler);
        }
      }, data2.timeout);
    });
  }
  executeAndSendInTab(data2.tabId, watchEvent, send2);
}
var handlers = {
  begin,
  end,
  list,
  goto,
  get,
  click,
  type,
  run: run2,
  waitForNetworkIdle,
  waitForSelector,
  waitForEvent
};
chrome.runtime.onMessageExternal.addListener((request, _, send2) => {
  const { action, data: data2 } = request;
  const handler = handlers[action];
  if (!handler) {
    error(send2, `Unknown action: ${action}`);
    return;
  }
  try {
    handler(send2, data2);
  } catch (err) {
    console.error(err);
    error(send2, err.toString());
  }
});
